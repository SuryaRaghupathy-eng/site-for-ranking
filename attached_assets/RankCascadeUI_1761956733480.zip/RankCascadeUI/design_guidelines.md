# RankCascade Design Guidelines

## Design Approach

**Selected Approach:** Design System (Material Design) with Modern SaaS Aesthetic

Drawing inspiration from professional SEO tools (Ahrefs, SEMrush) and modern SaaS interfaces (Linear), this design prioritizes clarity, trust, and conversion optimization for a rank tracking tool.

## Typography System

**Font Families:**
- Primary: Inter (via Google Fonts) - for UI, forms, and body text
- Headings: Inter SemiBold/Bold for hierarchy

**Type Scale:**
- Hero/Main Heading: text-4xl md:text-5xl font-bold
- Section Headings: text-2xl md:text-3xl font-semibold
- Subheadings: text-xl font-medium
- Body/Labels: text-base
- Helper Text: text-sm text-gray-600

## Layout System

**Spacing Primitives:** Tailwind units of 2, 4, 6, 8, and 12
- Component padding: p-6 to p-8
- Section spacing: py-12 md:py-16
- Form element gaps: gap-4 to gap-6
- Input field spacing: mb-4 to mb-6

**Container Strategy:**
- Max-width: max-w-4xl for form sections (centered focus)
- Padding: px-4 md:px-6
- Form cards: Well-defined containers with subtle borders/shadows

## Component Library

### A. Navigation & Branding
**Header:**
- Sticky top navigation with RankCascade logo (left-aligned)
- Clean, minimal header with subtle border-bottom
- Height: h-16 to h-20
- Background: White/light with slight shadow

### B. Toggle Component (Ranking Type Selector)
**Segmented Control Design:**
- Pill-style toggle button group
- Two options: "Local Ranking" | "Organic Ranking"
- Active state: Filled background with smooth transition
- Inactive state: Transparent with border
- Width: Full width on mobile, auto-width on desktop
- Prominent placement above form inputs
- Spacing: mb-8

### C. Form Components

**Input Field Structure:**
All inputs follow consistent pattern:
- Label: font-medium, mb-2, text-gray-700
- Input height: h-12 to h-14 (comfortable touch targets)
- Border: 2px border with focus state ring
- Border radius: rounded-lg
- Padding: px-4
- Font size: text-base
- Placeholder text: text-gray-400

**Location Dropdown:**
- Custom styled select with dropdown icon
- Display format: "Country Name (GL Code)" e.g., "United States (US)"
- Search functionality for long lists
- Height matches other inputs (h-12 to h-14)

**Primary Form Card:**
- Background: White card with subtle shadow (shadow-lg)
- Padding: p-8 md:p-10
- Border radius: rounded-2xl
- Border: Optional subtle border (border-gray-200)
- Contains: Toggle → Input Fields → Submit Button
- Grid layout on desktop: 2 columns for Brand/Branch

### D. Contact Form Section

**Section Structure:**
- Eye-catching headline: "Get 10 More Keyword Rankings for Free"
- Headline styling: text-3xl font-bold, text-center, mb-8
- Supporting subtext: Brief value proposition (1-2 lines)
- Spacing from main form: mt-16 to mt-20

**Contact Form Card:**
- Similar styling to main form card (visual consistency)
- Single column layout (stacked fields)
- Fields: Name, Email, Contact Number
- All fields required with validation indicators
- Submit button: Full-width on mobile, auto on desktop

### E. Buttons

**Primary Action Button (Submit/Get Rankings):**
- Height: h-12 to h-14
- Padding: px-8 py-3
- Font: font-semibold text-base
- Border radius: rounded-lg
- Full width on mobile, auto-width on desktop
- Loading state: Disabled appearance with spinner

**Button Hierarchy:**
- Primary (main CTAs): Bold, high contrast
- Secondary (if needed): Outlined style

### F. Layout Pattern

**Page Structure (Top to Bottom):**

1. **Header Section:** Minimal navigation with logo
2. **Hero/Main Tool Section:**
   - Centered layout (max-w-4xl)
   - RankCascade branding/logo at top
   - Brief tagline: "Track Your Rankings with Precision"
   - Padding: py-12 md:py-16

3. **Ranking Tool Card:**
   - Toggle control (Local/Organic)
   - Form inputs in logical order: Keyword → Brand Name → Branch → Location
   - Prominent "Check Rankings" button
   - Helper text: Character limits, examples

4. **Lead Generation Section:**
   - Generous spacing from tool (mt-16 to mt-20)
   - Attention-grabbing headline
   - Clean contact form
   - Trust indicators: "No credit card required" or similar

5. **Footer:** Minimal with links, copyright

## Visual Treatment

**Cards & Elevation:**
- Primary cards: shadow-lg with rounded-2xl
- Hover states on interactive elements: Subtle lift (transform scale)
- Focus states: Prominent ring (ring-2 ring-offset-2)

**Visual Hierarchy:**
- Clear separation between tool section and contact section
- Progressive disclosure: Most important info first
- White space: Generous breathing room between sections

**Consistency:**
- All inputs same height and styling
- Consistent border radius across all components
- Unified shadow system

## Form Validation & States

**Input States:**
- Default: Neutral border
- Focus: Highlighted border with ring
- Error: Red border with error message below (text-sm text-red-600)
- Success: Green border (optional check icon)
- Disabled: Reduced opacity

**Validation Messages:**
- Position: Below input field
- Spacing: mt-1
- Icon + text pattern for clarity

## Responsive Behavior

**Mobile (base to md):**
- Single column form layouts
- Full-width buttons
- Stack all form fields
- Increased touch targets (min h-12)

**Desktop (md and up):**
- 2-column grid for Brand/Branch fields
- Side-by-side layout where beneficial
- Constrained max-width for readability

## Accessibility

- ARIA labels on all form inputs
- Clear focus indicators (never remove outline)
- Error announcements for screen readers
- Logical tab order
- Required field indicators (asterisk + label)
- Sufficient color contrast (WCAG AA minimum)

## Images

**Logo/Branding:** RankCascade logo in header (SVG, max-height: 40px)

**No Hero Image Required:** This is a tool-focused landing page. The form itself is the hero element, demanding immediate attention and action.

**Icons:** Material Icons or Heroicons for:
- Search icon (keyword field)
- Location pin (location dropdown)
- User/email icons (contact form)
- Toggle indicators