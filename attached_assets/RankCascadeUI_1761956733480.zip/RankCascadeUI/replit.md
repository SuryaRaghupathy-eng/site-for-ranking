# RankCascade - Rank Tracking Tool

## Overview

RankCascade is a professional SEO rank tracking application that allows users to monitor keyword rankings across both local and organic search results. The application features a modern SaaS interface inspired by professional SEO tools like Ahrefs and SEMrush, with a clean, conversion-optimized design. Users can submit ranking requests for specific keywords, brands, and locations, and submit contact forms for inquiries.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework:** React with TypeScript using Vite as the build tool

**Routing:** Wouter for client-side routing with a minimal two-page setup (Home and NotFound pages)

**State Management:** 
- TanStack Query (React Query) for server state management and data fetching
- React Hook Form with Zod resolver for form state and validation

**UI Component Library:**
- Shadcn UI (New York style variant) with Radix UI primitives
- Tailwind CSS for styling with custom design tokens
- CSS variables for theming support (light/dark modes)

**Design System:**
- Typography: Inter font family from Google Fonts
- Color system based on HSL values with CSS custom properties
- Responsive spacing using Tailwind's utility-first approach
- Component-driven architecture with reusable UI primitives

**Key Design Decisions:**
- Chose Shadcn/Radix UI for accessible, composable components that can be customized
- Tailwind CSS provides rapid development while maintaining design consistency
- CSS variables enable easy theme switching and maintainability
- React Hook Form reduces re-renders and provides better performance than controlled components

### Backend Architecture

**Framework:** Express.js with TypeScript running on Node.js

**API Design:** RESTful API with JSON responses
- POST/GET `/api/rank-tracking` - Create and retrieve rank tracking requests
- POST/GET `/api/contact` - Create and retrieve contact submissions

**Validation:** Zod schemas shared between frontend and backend for type safety and runtime validation

**Storage Strategy:**
- Interface-based storage abstraction (`IStorage`) for flexibility
- Current implementation: In-memory storage using JavaScript Maps
- Database-ready architecture with Drizzle ORM configured for PostgreSQL migration

**Error Handling:**
- Zod validation errors converted to user-friendly messages using `zod-validation-error`
- Structured error responses with appropriate HTTP status codes
- Request/response logging middleware for debugging

**Key Architectural Decisions:**
- Express chosen for simplicity and wide ecosystem support
- Storage abstraction allows switching from in-memory to PostgreSQL without changing business logic
- Shared Zod schemas eliminate duplication and ensure consistency between client and server
- TypeScript across the stack provides end-to-end type safety

### Data Storage

**Current Implementation:** In-memory storage with three primary entities:
- Users (with username/password authentication structure)
- Rank Tracking Requests (keyword, brand, location, ranking type)
- Contact Submissions (name, email, contact number)

**Prepared for Migration:**
- Drizzle ORM configured for PostgreSQL via Neon Database serverless driver
- Schema definitions in `shared/schema.ts` using Drizzle's pgTable
- Migration configuration ready in `drizzle.config.ts`
- Database URL expected via `DATABASE_URL` environment variable

**Schema Design:**
- UUID primary keys using `gen_random_uuid()`
- Timestamp tracking with `created_at` fields
- Text/varchar fields for user input with appropriate constraints
- Zod schemas derived from Drizzle tables for automatic validation

**Key Decisions:**
- In-memory storage allows rapid development and testing without database setup
- Drizzle ORM chosen for type-safe database queries and automatic migrations
- Neon serverless PostgreSQL enables edge deployment and scaling
- Schema-first approach ensures database structure matches application types

### External Dependencies

**UI Component Libraries:**
- @radix-ui/* (v1.x) - Headless UI primitives for accessibility
- shadcn/ui - Pre-built components built on Radix UI
- lucide-react - Icon library
- embla-carousel-react - Carousel/slider functionality

**Form Management:**
- react-hook-form (v7.x) - Form state management
- @hookform/resolvers - Zod integration for validation
- zod (via drizzle-zod) - Schema validation

**Data Fetching:**
- @tanstack/react-query (v5.x) - Server state management
- Native fetch API for HTTP requests

**Styling:**
- tailwindcss - Utility-first CSS framework
- class-variance-authority - Component variant management
- clsx + tailwind-merge - Conditional class merging

**Database (Prepared):**
- drizzle-orm - TypeScript ORM
- @neondatabase/serverless - Serverless PostgreSQL driver
- drizzle-kit - Schema migrations and management

**Development Tools:**
- vite - Build tool and dev server
- typescript - Type checking
- tsx - TypeScript execution for development
- esbuild - Production bundling for server code
- @replit/* plugins - Replit-specific integrations

**Routing:**
- wouter - Lightweight React router (alternative to react-router)

**Utilities:**
- date-fns - Date manipulation
- nanoid - ID generation
- cmdk - Command palette primitive (for future features)

**Key Integration Decisions:**
- Radix UI provides unstyled, accessible components that can be fully customized
- React Query handles caching, revalidation, and loading states automatically
- Drizzle integrates with Zod to generate validators directly from database schema
- Vite's fast HMR improves developer experience significantly over webpack
- Wouter chosen over React Router for smaller bundle size and simpler API