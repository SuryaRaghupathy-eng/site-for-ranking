import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertRankTrackingRequestSchema, insertContactSubmissionSchema } from "@shared/schema";
import { fromZodError } from "zod-validation-error";

export async function registerRoutes(app: Express): Promise<Server> {
  app.post("/api/rank-tracking", async (req, res) => {
    try {
      const validatedData = insertRankTrackingRequestSchema.parse(req.body);
      const request = await storage.createRankTrackingRequest(validatedData);
      res.json(request);
    } catch (error: any) {
      if (error.name === "ZodError") {
        const validationError = fromZodError(error);
        res.status(400).json({ message: validationError.message });
      } else {
        res.status(500).json({ message: "Failed to create rank tracking request" });
      }
    }
  });

  app.get("/api/rank-tracking", async (req, res) => {
    try {
      const requests = await storage.getRankTrackingRequests();
      res.json(requests);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch rank tracking requests" });
    }
  });

  app.post("/api/contact", async (req, res) => {
    try {
      const validatedData = insertContactSubmissionSchema.parse(req.body);
      const submission = await storage.createContactSubmission(validatedData);
      res.json(submission);
    } catch (error: any) {
      if (error.name === "ZodError") {
        const validationError = fromZodError(error);
        res.status(400).json({ message: validationError.message });
      } else {
        res.status(500).json({ message: "Failed to create contact submission" });
      }
    }
  });

  app.get("/api/contact", async (req, res) => {
    try {
      const submissions = await storage.getContactSubmissions();
      res.json(submissions);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch contact submissions" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
