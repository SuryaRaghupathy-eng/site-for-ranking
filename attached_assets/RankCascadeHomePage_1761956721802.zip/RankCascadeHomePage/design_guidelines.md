# RankCascade Homepage Design Guidelines

## Design Approach
Reference-based approach inspired by BrightLocal's professional SaaS aesthetic, combined with modern dashboard UI patterns from Linear and Stripe. The design prioritizes trust, clarity, and feature demonstration for a local SEO rank tracking tool.

## Typography System

**Primary Font**: Inter or DM Sans (Google Fonts CDN)
**Secondary Font**: Same as primary (single-family approach)

**Hierarchy**:
- Hero Headline: text-5xl/text-6xl, font-bold, leading-tight
- Section Headlines: text-3xl/text-4xl, font-bold
- Feature Titles: text-xl, font-semibold
- Body Text: text-base/text-lg, font-normal, leading-relaxed
- Small Text/Captions: text-sm, font-medium

## Layout System

**Spacing Primitives**: Tailwind units of 4, 6, 8, 12, 16, 20, 24, 32
- Component spacing: p-6, p-8
- Section padding: py-16, py-20, py-24
- Container gaps: gap-8, gap-12, gap-16
- Margins between sections: my-16, my-20

**Container Widths**:
- Full sections: w-full with max-w-7xl centered
- Content blocks: max-w-6xl
- Text content: max-w-4xl

**Grid Systems**:
- Feature cards: grid-cols-1 md:grid-cols-2 lg:grid-cols-3
- Two-column sections: grid-cols-1 lg:grid-cols-2 with gap-12
- Testimonials: grid-cols-1 md:grid-cols-2 lg:grid-cols-3

## Page Structure & Components

### 1. Header/Navigation
- Fixed/sticky navigation with RankCascade logo (left-aligned)
- Right-aligned navigation: "Features", "Pricing", "Resources", "Login", "Try for Free" button
- Height: h-16 to h-20
- Subtle shadow on scroll

### 2. Hero Section
- Height: min-h-[600px] to min-h-[700px]
- Two-column layout (60/40 split)
- Left: Headline + subheadline + CTA button + trust indicator ("No credit card required")
- Right: Large product dashboard screenshot/illustration showing rank tracking interface
- Background: Subtle gradient overlay
- Primary CTA button with backdrop-blur effect

### 3. Feature Grid Section
- 2x3 grid (6 features total)
- Each card: Icon + Title + Description
- Icons: Heroicons (outline style, size w-10 h-10)
- Cards: Minimal border, rounded-lg, p-6
- Features to highlight:
  - SERP Snapshots & Data Storage
  - Search Volume Sorting
  - Keyword Grouping
  - Location Simulation
  - Custom Dashboards
  - Search Engine Customization

### 4. Alternating Feature Sections (4 sections)
- Image-text alternating layout (left-right-left-right)
- Each section: py-20 spacing
- Image side: 45% width, rounded-xl with subtle shadow
- Content side: 50% width with headline, description, optional bullets
- Sections:
  1. "Your source of truth for local rankings" - dashboard screenshot
  2. "Make smarter decisions, faster" - analytics graph visualization
  3. "Get the competitive edge" - competitor comparison interface
  4. "Clear, comprehensive reporting" - report preview

### 5. Agency/Scale Focused Sections
- Two side-by-side cards with icons
- "Awesome for agencies" - white-label features
- "Spectacular at scale" - multi-location management
- Rounded cards with p-8, decorative icons

### 6. Testimonials Section
- Grid of 6 testimonials (3 columns on desktop)
- Each card: 5-star rating, quote, headshot, name, company
- Rounded borders, p-6
- "Read more reviews" link below grid

### 7. FAQ Section
- Accordion component with 3-4 questions
- Questions about local rank tracking, SEO importance, tool usage
- Expandable/collapsible with smooth transitions
- max-w-3xl centered

### 8. Final CTA Section
- Centered content, py-20
- Headline + CTA button
- "Why choose RankCascade?" with 2-3 benefit bullets

### 9. Footer
- Multi-column layout (4 columns)
- Columns: Product, Resources, Company, Contact
- Social media icons
- Copyright and legal links
- Newsletter signup form

## Component Library

**Buttons**:
- Primary: Rounded-lg, px-6 py-3, font-semibold, backdrop-blur when on images
- Secondary: Outline style with border
- Hover states with subtle scale/shadow transitions

**Cards**:
- Feature cards: Rounded-lg, border, p-6, hover:shadow-lg transition
- Testimonial cards: Rounded-xl, subtle shadow, p-6

**Icons**:
- Heroicons via CDN (outline for features, solid for UI elements)
- Size: w-6 h-6 for inline, w-10 h-10 for feature cards

**Form Elements**:
- Newsletter input: Rounded-lg, border, px-4 py-3
- Inline button placement for email capture

**Badges/Tags**:
- Small rounded-full pills for trust indicators ("Trusted by 5000+ agencies")
- px-3 py-1, text-sm

## Images Section

**Hero Image** (Required - Large):
- RankCascade dashboard interface showing rank tracking table with keywords, positions, and trend graphs
- Clean, modern UI with organized data columns
- Dimensions: Minimum 800x600px
- Style: Modern SaaS dashboard aesthetic with clear hierarchy

**Feature Section Images** (4 required):
1. Dashboard overview showing comprehensive rank data with filters and sorting
2. Analytics graphs with upward trends, colorful charts showing ranking improvements
3. Competitor comparison table with multiple businesses side-by-side
4. White-label report preview with professional branding

**Testimonial Images**:
- 6 professional headshots (circular crops, 128x128px)
- Mix of diverse professionals

**Decorative Icons**:
- Chart/graph illustrations for "Make smarter decisions"
- Trophy/target icons for competitive features
- Report/document icons for reporting sections

## Visual Hierarchy

**Emphasis Through Scale**:
- Hero headline is largest (60-72px desktop)
- Section headlines step down (36-48px)
- Feature titles (20-24px)
- Body text maintains consistency (16-18px)

**Whitespace Strategy**:
- Generous section spacing (80-96px vertical)
- Contained content widths prevent overwhelming layouts
- Card padding creates breathing room
- Feature grids use gap-8 to gap-12

**Depth & Elevation**:
- Subtle shadows on cards (shadow-sm base, shadow-lg hover)
- Layered sections with background variations
- Elevated CTAs with stronger shadows

## Accessibility

- High contrast text ratios
- Focus states on all interactive elements (ring-2 ring-offset-2)
- Semantic HTML structure
- Alt text for all images
- ARIA labels for icon-only buttons
- Keyboard navigation support for accordion/collapsible elements

## Animation Guidelines

**Minimal, Purposeful Motion**:
- Smooth scroll-triggered fade-ins for sections (opacity + translate-y)
- Card hover effects (scale-105, shadow transitions)
- Button hover states (subtle scale or shadow)
- Accordion expand/collapse (height transition)
- NO parallax, NO scroll-jacking, NO auto-playing carousels

## Responsive Behavior

**Mobile (< 768px)**:
- Single column layouts
- Stacked hero (headline above image)
- Vertical testimonial cards
- Hamburger menu for navigation
- Full-width CTAs
- Reduced font sizes (scale down by 20-30%)

**Tablet (768-1024px)**:
- 2-column feature grids
- Maintained alternating sections
- Adjusted spacing (py-12 instead of py-20)

**Desktop (1024px+)**:
- Full multi-column layouts
- Maximum content widths enforced
- Generous spacing applied