import AgencySection from '../AgencySection';

export default function AgencySectionExample() {
  return <AgencySection />;
}