import BenefitSection from '../BenefitSection';

export default function BenefitSectionExample() {
  return <BenefitSection />;
}