import FeatureGrid from '../FeatureGrid';

export default function FeatureGridExample() {
  return <FeatureGrid />;
}